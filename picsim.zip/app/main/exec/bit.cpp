#include "instructionex.h"
#include "../instruction.h"
#include "../memory/ram.h"
#include <cstdint>

    BitExecution::BitExecution(InstructionExecution& executor) : executor(executor) {}

    void BitExecution::executeBCF(const Instruction& instruction) {
        int address = executor.getFileAddress(instruction);
        RamMemory<uint8_t>::Bank bank = executor.getSelectedBank(instruction);

        uint8_t value = executor.getRamContent(bank, address); // Fetch value from given file register
        uint8_t mask = static_cast<uint8_t>(0x01 << instruction.getArguments()[0]);

        value = static_cast<uint8_t>(value & ~mask); // Clear bit using the mask

        executor.setRamContent(bank, address, value);
    }

    /**
     * Sets the selected bit inside of a file register.
     *
     * @param instruction Instruction consisting of OPC and arguments.
     */
    void BitExecution::executeBSF(const Instruction& instruction) {
        int address = executor.getFileAddress(instruction);
        auto bank = executor.getSelectedBank(instruction);

        uint8_t value = executor.getRamContent(bank, address); // Fetch value from given file register
        uint8_t mask = static_cast<uint8_t>(0x01 << instruction.getArguments()[0]);

        value = static_cast<uint8_t>(value | mask); // Set bit using the mask

        executor.setRamContent(bank, address, value);
    }

    /**
     * Test if given bit in file register is clear, if yes skip next instruction otherwise
     * execute it.
     *
     * @param instruction Instruction consisting of OPC and arguments.
     */
    void BitExecution::executeBTFSC(const Instruction& instruction) {
        int address = executor.getFileAddress(instruction);
        auto bank = executor.getSelectedBank(instruction);

        uint8_t value = executor.getRamContent(bank, address); // Fetch value from given file register
        uint8_t bit = static_cast<uint8_t>(0x01 << instruction.getArguments()[0]);

        if ((value & bit) == 0) { // Check if bit is clear
            // Skip the next operation by incrementing the program counter
            executor.setProgramCounter(executor.getProgramCounter() + 1);
        }
    }

    /**
     * Test if given bit in file register is set, if yes skip next instruction otherwise
     * execute it.
     *
     * @param instruction Instruction consisting of OPC and arguments.
     */
    void BitExecution::executeBTFSS(const Instruction& instruction) {
        int address = executor.getFileAddress(instruction);
        auto bank = executor.getSelectedBank(instruction);

        uint8_t value = executor.getRamContent(bank, address); // Fetch value from given file register
        uint8_t bit = static_cast<uint8_t>(0x01 << instruction.getArguments()[0]);

        if ((value & bit) != 0) { // Check if bit is set
            // Skip the next operation by incrementing the program counter
            executor.setProgramCounter(executor.getProgramCounter() + 1);
        }
    }
