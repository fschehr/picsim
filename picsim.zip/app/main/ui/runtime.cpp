#include <ftxui/dom/elements.hpp>
#include <ftxui/component/component.hpp>
#include <cctype>  // Für isdigit
#include <iostream> // Für std::cout

ftxui::Component Runtime() {
    using namespace ftxui;

    static std::string runtime = "0000";

    static std::string frequency; // in Hz
    static std::string microseconds;
    static bool invalidInput = false;

    InputOption inputOption;
    inputOption.on_change = [&]() {
        invalidInput = false;
        if (!frequency.empty()) {
            for (char c : frequency) {
                if (!std::isdigit(c)) {
                    invalidInput = true;
                    break;
                } else {
                    microseconds = std::to_string(4 / std::stoi(frequency)); // 4 / Cycles = Microseconds per Cycle
                }
            }
        }
    };

    Component frequencyInput = Input(&frequency, "Frequency (Hz)", inputOption);

    auto container = Container::Vertical({
        frequencyInput
    });

    auto registers_renderer = Renderer(container, [
        frequencyInput
    ] {
        return window(
            text(" Runtime "),
            vbox({
                hbox({
                    hbox({
                        frequencyInput->Render() | xflex,
                        center(
                            text("  →  ") | xflex
                        ),
                        text(microseconds + "µs") | align_right | xflex,
                    }) | flex,
                    text("  ⇒  ") | xflex,
                    text(" Runtime ") | bgcolor(Color::White) | color(Color::Black) | xflex,
                    text(" " + runtime + "µs ") | bgcolor(Color::GrayLight) | color(Color::Black) | xflex,
                }) | center,
                invalidInput ? text("Invalid input") | bgcolor(Color::IndianRed) | color(Color::White) | xflex : vbox({}) | size(WIDTH, EQUAL, 0),
            }) | xflex
        );
    });

    return registers_renderer;
}