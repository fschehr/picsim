#include <ftxui/component/component.hpp>

ftxui::Component Document();